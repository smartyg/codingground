<?php
require_once("XHTMLSpec.php");

abstract class BasicHTMLObject
{
	protected $strict = true;
	protected $spec = NULL;
	
	abstract public function validate(HTMLSpec &$spec = NULL);
	abstract public function printHTML(HTMLSpec &$spec = NULL);
	
	function __construct()
	{
	    $this->spec = new XHTMLSpec();
	}
	
	public function setSpec(HTMLSpec &$spec)
	{
		$this->spec = $spec;
	}
	
	public function setStrict($strict)
	{
		$this->strict = $strict;
	}	
}
?>
