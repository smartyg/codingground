<?php
abstract class HTMLSpec
{
	function __construct()
	{
	}
	/*
	list possible tags, read from config file when class in called (only once). Routines shoud go here, instances should have 0 to minimum code.
	
	type_list = {tag, type, list_extra_attr, list_extra_subs}
	
	type {list_tags, list_attr, value_allowed, list_subs, explicite_close}
	
	attr {}???
}
?>