<?php
require_once("BasicHTMLObject.php");

class TagObject extends BasicHTMLObject
{
	private $name;
	private $attr;
	private $subs;
	private $value;
  
	function __construct($name, array $attrs = NULL, $subs = NULL, $strict = NULL, HTMLSpec &$spec = NULL)
	{
	    parent::__construct();
		if($strict) $this->strict = $strict;
		if($spec) $this->spec = $spec;
  		$this->name = ($this->strict ? self::validateTagName($name, $this->spec) : $name);
		if(is_array($attrs))
		{
		    foreach($attrs as $attr)
		    {
			    if($this->strict)
				    $attr = self::validateAttr($this->name, $attr, $this->spec);
			    if($attr) $this->attrs[] = $attr;
		    }
		}
		if(is_array($subs))
		{
		    $this->value = NULL;
		    foreach($subs as $sub)
		    {
			    if($this->strict)
				    $sub = self::validateSub($this->name, $sub, $this->spec);
			    if($sub) $this->subs[] = $sub;
		    }
		}
		elseif(is_string($subs))
		{
		    $this->value = ($this->strict ? self::validateValue($this->name, $subs, $this->spec) : $subs);
		    $this->subs = NULL;
		}
	}
	
	public static function validateTagName($tag, HTMLSpec &$spec)
	{
		return $tag;
	}
	
	private static function validateAttr($tag, AttrObject $attr, HTMLSpec &$spec)
	{
		if($attr->validate($spec))
			return $attr;
		else
			return NULL;
	}
	private static function validateSub($tag, TagObject $sub, HTMLSpec &$spec)
	{
		if($sub->validate($spec))
			return $sub;
		else
		   return NULL;
	}
	
	protected static function validateValue($tag, $value, HTMLSpec &$spec)
	{
	    return $value;
	}
	
	protected static function expliciteClose($tag, HTMLSpec $spec)
	{
        return true;
	}
	
	public function validate(HTMLSpec &$spec = NULL)	
	{
	    if(!$spec) $spec = $this->spec;
		if(!self::validateTagName($this->name, $spec)) return FALSE;
		foreach($this->attrs as $attr)
			if(!self::validateAttr($this->name, $attr, $spec)) return FALSE;
		foreach($this->subs as $sub)
			if(!self::validateSub($this->name, $sub, $spec)) return FALSE;
		return TRUE;
	}
	
	public function printHTML(HTMLSpec &$spec = NULL)
	{
	    if(!$spec) $spec = $this->spec;
		echo '<' . $this->name;
		if($this->attrs)
			foreach($this->attrs as $attr)
			{
			    echo ' ';
				$attr->printHTML($strict, $spec);
			}
		if($this->subs || self::expliciteClose($this->name, $spec))
		{
			echo '>';
			if($this->subs)
			{
				foreach($this->subs as $sub)
					$sub->printHTML($strict, $spec);
			}
			elseif($this->value)
			    echo $this->value;
			echo '</' . $this->name . '>';
		}
		else
			echo ' />';
	}
}
?>