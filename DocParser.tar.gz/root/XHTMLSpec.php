<?php
require_once("HTMLSpec.php");

class XHTMLSpec extends HTMLSpec
{
    function __construct()
    {
    }
}
?>