<?php
    require("AttrObject.php");
    require("TagObject.php");

    $attrs[0] = new AttrObject("href", "http://www.google.nl");
    $obj = new TagObject("a", $attrs, "google");
?>
<html>
<head>
<title>Online PHP Script Execution</title>
</head>
<body>
<?php
   echo "<h1>Hello, PHP!</h1>";

   $obj->printHTML();
?>
</body>
</html>
